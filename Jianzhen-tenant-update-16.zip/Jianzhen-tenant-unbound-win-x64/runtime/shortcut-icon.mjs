import { execFile } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdir, rename, rm, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { promisify } from 'node:util'

const run = promisify(execFile)
const pngSignature = Buffer.from([137,80,78,71,13,10,26,10])

export function desktopIco(png) {
  if (png.length<33 || !png.subarray(0,8).equals(pngSignature) || png.toString('ascii',12,16)!=='IHDR' ||
      png.readUInt32BE(16)!==256 || png.readUInt32BE(20)!==256)
    throw new Error('桌面图标须为 256 像素的 PNG')
  const header = Buffer.alloc(22)
  header.writeUInt16LE(1,2)
  header.writeUInt16LE(1,4)
  header.writeUInt16LE(1,10)
  header.writeUInt16LE(32,12)
  header.writeUInt32LE(png.length,14)
  header.writeUInt32LE(header.length,18)
  return Buffer.concat([header,png])
}

export function shortcutIconBinding(runtime,launcher,data) {
  const directory = join(data,'shortcut-icons')
  let pending = Promise.resolve()
  return async request=>{
    const png = Buffer.from(await request.arrayBuffer())
    const operation = pending.then(async()=>{
      let icon = ''
      if (png.length) {
        const bytes = desktopIco(png)
        const hash = createHash('sha256').update(bytes).digest('hex')
        icon = join(directory,hash+'.ico')
        await mkdir(directory,{recursive:true})
        const temporary = icon+'.tmp'
        try {
          await writeFile(temporary,bytes)
          await rename(temporary,icon)
        } finally { await rm(temporary,{force:true}) }
      }
      const {stdout} = await run(join(runtime,'ShortcutIcon.exe'),[launcher,directory,icon],{windowsHide:true,timeout:10000})
      return Response.json({matched:Number(stdout.trim())})
    })
    pending = operation.catch(error=>console.warn('桌面图标同步失败：'+error.message))
    try { return await operation }
    catch { return Response.json({error:'无法同步 Windows 桌面图标'},{status:500}) }
  }
}
