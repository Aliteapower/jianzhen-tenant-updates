ALTER TABLE item_movements ADD COLUMN source_id TEXT REFERENCES item_movements(id);
ALTER TABLE item_movements ADD COLUMN legacy_claimed INTEGER NOT NULL DEFAULT 0 CHECK (legacy_claimed >= 0 AND legacy_claimed <= quantity);
CREATE INDEX item_claims_by_source ON item_movements(source_id,quantity) WHERE source_id IS NOT NULL;
UPDATE item_movements AS incoming
SET legacy_claimed=max(0,min(incoming.quantity,coalesce(claimed.total,0)-batches.previous_quantity))
FROM (
  SELECT id,tenant_id,ledger_id,name,
    coalesce(sum(quantity) OVER (PARTITION BY tenant_id,ledger_id,name ORDER BY created_at,id
      ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING),0) AS previous_quantity
  FROM item_movements WHERE kind='income'
) AS batches LEFT JOIN (
  SELECT tenant_id,ledger_id,name,sum(quantity) AS total FROM item_movements
  WHERE kind='expense' AND source_id IS NULL GROUP BY tenant_id,ledger_id,name
) AS claimed ON claimed.tenant_id=batches.tenant_id AND claimed.ledger_id=batches.ledger_id AND claimed.name=batches.name
WHERE incoming.id=batches.id AND claimed.total IS NOT NULL;
