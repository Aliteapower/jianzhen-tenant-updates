ALTER TABLE item_movements ADD COLUMN reason TEXT NOT NULL DEFAULT '';

CREATE TABLE entry_presets_next (
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  kind TEXT NOT NULL CHECK(kind IN ('funding','source','payee','handler','itemReason')),
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  PRIMARY KEY (tenant_id,kind,name)
);
INSERT INTO entry_presets_next SELECT tenant_id,kind,name,active FROM entry_presets;
DROP TABLE entry_presets;
ALTER TABLE entry_presets_next RENAME TO entry_presets;

INSERT INTO entry_presets(tenant_id,kind,name)
SELECT tenants.id,'itemReason',defaults.name FROM tenants
CROSS JOIN (SELECT '正常领用' AS name UNION ALL SELECT '借用' UNION ALL SELECT '销毁') AS defaults;

CREATE TRIGGER seed_item_outbound_reasons AFTER INSERT ON tenants
BEGIN
  INSERT INTO entry_presets(tenant_id,kind,name) VALUES
    (NEW.id,'itemReason','正常领用'),(NEW.id,'itemReason','借用'),(NEW.id,'itemReason','销毁');
END;
