import { readFile, readdir } from 'node:fs/promises'
import { join } from 'node:path'

export async function migrationFiles(directory) {
  return (await readdir(directory)).filter(name=>/^\d{4}_.+\.sql$/.test(name)).sort()
}

export async function migrationStatements(directory,name) {
  const script = await readFile(join(directory,name),'utf8')
  return script.trim().split(/;\s*(?=CREATE|INSERT|ALTER|UPDATE|DROP|$)/).filter(Boolean)
}
