import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { installTenantActivation } from './offline-tenant.mjs'

const runtime=dirname(fileURLToPath(import.meta.url))
try {
  await installTenantActivation(runtime,join(runtime,'..','data'),process.argv[2])
} catch (error) {
  console.error(error.message)
  process.exitCode=1
}
