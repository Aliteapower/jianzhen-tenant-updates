import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { acceptTenantActivation } from './offline-tenant.mjs'

const runtime=dirname(fileURLToPath(import.meta.url))
try {
  let input=''
  for await (const chunk of process.stdin) {
    input+=chunk
    if (input.length>5000) throw new Error('激活信息过长')
  }
  const [server,code,password]=input.trim().split(/\r?\n/)
  if (!/^\d{6}$/.test(code || '') || !/^\d{6}$/.test(password || ''))
    throw new Error('请输入 6 位激活码和管理员密码')
  const url=new URL(server)
  if (url.username || url.password || url.pathname!=='/' || url.search || url.hash ||
      (url.protocol!=='https:' && !(url.protocol==='http:' && url.hostname==='127.0.0.1')))
    throw new Error('请输入 HTTPS 授权服务器地址，本机测试可用 127.0.0.1')
  const response=await fetch(new URL('/api/activation-codes/redeem',url),{
    method:'POST',redirect:'error',signal:AbortSignal.timeout(8000),
    headers:{'Content-Type':'application/json'},body:JSON.stringify({code,password}),
  })
  if (!response.ok) {
    if (response.status===400) throw new Error('激活码无效、已过期或管理员密码不正确')
    if (response.status===429) throw new Error('请求过于频繁，请稍后再试')
    throw new Error('授权服务暂时不可用，请联系平台')
  }
  const body=await response.text()
  if (body.length>20000) throw new Error('授权响应不正确')
  await acceptTenantActivation(runtime,join(runtime,'..','data'),JSON.parse(body).activation)
} catch (error) {
  console.error(error instanceof TypeError ? '无法连接授权服务，请检查地址和网络' : error.message)
  process.exitCode=1
}
