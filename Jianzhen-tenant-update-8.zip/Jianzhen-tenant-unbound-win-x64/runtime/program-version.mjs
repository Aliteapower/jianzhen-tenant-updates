import { join } from 'node:path'
import { cachedManifest, readJson } from './git-channel.mjs'
import { readTenantUpdate } from './tenant-update.mjs'

export async function desktopProgram(runtime,data,channel) {
  const metadata=await readJson(join(runtime,'desktop-version.json'))
  const serial=channel?.serial ?? metadata?.serial ?? null
  let latest=null
  let pending=null
  let failed=false

  async function status() {
    const ready=channel && await readJson(join(data,'program-versions','ready.json')).catch(()=>null)
    const prepared=ready?.serial>serial && Boolean(ready.tenant)===Boolean(channel?.tenant)
    return {serial,channelAvailable:Boolean(channel),manualDownload:Boolean(channel?.tenant),checked:Boolean(latest),
      availableSerial:latest?.serial>serial ? latest.serial : null,
      readySerial:prepared ? ready.serial : null,updating:Boolean(pending),failed}
  }

  function run(download) {
    if (!channel) return Promise.resolve()
    if (!pending) {
      failed=false
      pending=(async()=>{
        try {
          if (channel.tenant) {
            if (!download || !latest) {
              const manifest=await readTenantUpdate(channel)
              if (!latest || manifest.serial>=latest.serial) latest=manifest
            }
          } else latest=await cachedManifest(channel,'update') || latest
          if (download) {
            const {stageUpdate}=await import('./update.mjs')
            await stageUpdate(channel,serial,latest)
          }
        } catch (error) {
          failed=true
          console.warn('无法准备程序更新：'+error.message)
        } finally { pending=null }
      })()
    }
    return pending
  }

  return {prepare:()=>run(true),async binding(request) {
    if (request.method==='POST') await run(new URL(request.url).searchParams.get('action')!=='check' || !channel?.tenant)
    return Response.json(await status())
  }}
}
