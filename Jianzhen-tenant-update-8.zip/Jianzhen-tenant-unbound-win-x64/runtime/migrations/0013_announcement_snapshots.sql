CREATE TABLE announcement_snapshots (
  version TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  created_at INTEGER NOT NULL,
  ledger_count INTEGER NOT NULL
);
CREATE INDEX announcement_snapshots_listing ON announcement_snapshots(tenant_id,created_at DESC,version);
