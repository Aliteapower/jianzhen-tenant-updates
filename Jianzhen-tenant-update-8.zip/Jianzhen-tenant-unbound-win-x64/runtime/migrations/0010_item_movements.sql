CREATE TABLE item_movements (
  id TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  ledger_id TEXT NOT NULL,
  kind TEXT NOT NULL CHECK(kind IN ('income','expense')),
  date TEXT NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK(quantity > 0),
  unit_price INTEGER CHECK(unit_price >= 0),
  amount INTEGER CHECK(amount >= 0),
  handler TEXT NOT NULL,
  location TEXT NOT NULL,
  notes TEXT NOT NULL,
  actor TEXT NOT NULL REFERENCES accounts(id),
  created_at INTEGER NOT NULL,
  FOREIGN KEY(tenant_id,ledger_id) REFERENCES ledgers(tenant_id,id)
);
CREATE INDEX item_movements_listing ON item_movements(tenant_id,ledger_id,date DESC,created_at DESC,id DESC);
CREATE INDEX item_movements_stock ON item_movements(tenant_id,ledger_id,name,kind,quantity);
