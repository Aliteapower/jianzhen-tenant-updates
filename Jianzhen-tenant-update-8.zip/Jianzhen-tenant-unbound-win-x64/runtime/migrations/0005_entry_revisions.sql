ALTER TABLE entries ADD COLUMN revision INTEGER NOT NULL DEFAULT 0;
CREATE TABLE entry_revisions (
  entry_id TEXT NOT NULL REFERENCES entries(id), revision INTEGER NOT NULL,
  actor_id TEXT NOT NULL REFERENCES accounts(id), actor_name TEXT NOT NULL,
  at INTEGER NOT NULL, reason TEXT NOT NULL, changes TEXT NOT NULL,
  PRIMARY KEY(entry_id,revision)
);
