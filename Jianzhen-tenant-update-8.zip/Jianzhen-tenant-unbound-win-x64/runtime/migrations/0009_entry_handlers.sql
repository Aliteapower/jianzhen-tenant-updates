CREATE TABLE entry_presets_next (
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  kind TEXT NOT NULL CHECK(kind IN ('funding','source','payee','handler')),
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  PRIMARY KEY (tenant_id,kind,name)
);
INSERT INTO entry_presets_next SELECT tenant_id,kind,name,active FROM entry_presets;
DROP TABLE entry_presets;
ALTER TABLE entry_presets_next RENAME TO entry_presets;
