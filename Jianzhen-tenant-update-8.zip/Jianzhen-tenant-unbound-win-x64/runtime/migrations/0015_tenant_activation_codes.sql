CREATE TABLE tenant_activation_codes (
  code_hash TEXT PRIMARY KEY,
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  account_id TEXT NOT NULL REFERENCES accounts(id),
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  redeemed_at INTEGER
);
CREATE INDEX tenant_activation_expiry ON tenant_activation_codes(expires_at);
