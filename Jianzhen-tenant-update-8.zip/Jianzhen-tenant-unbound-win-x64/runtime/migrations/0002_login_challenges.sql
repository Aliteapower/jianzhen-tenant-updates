CREATE TABLE login_challenges (
  id TEXT PRIMARY KEY, code TEXT NOT NULL, expires INTEGER NOT NULL
);
