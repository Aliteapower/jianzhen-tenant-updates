CREATE TABLE categories (
  id TEXT PRIMARY KEY, tenant_id TEXT REFERENCES tenants(id), kind TEXT NOT NULL CHECK(kind IN ('income','expense')),
  name TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, requested INTEGER NOT NULL DEFAULT 0
);
CREATE UNIQUE INDEX category_name ON categories(COALESCE(tenant_id,''),kind,name);
INSERT INTO categories(id,kind,name) VALUES
  ('income-donation','income','捐款'),('income-interest','income','利息'),('income-rent','income','租金收入'),
  ('income-other','income','其他收入'),('income-unclassified','income','不分类'),
  ('expense-electricity','expense','电费'),('expense-communications','expense','通讯费'),('expense-water','expense','水费'),
  ('expense-gas','expense','煤气费'),('expense-transport','expense','交通费'),('expense-lodging','expense','住宿费'),
  ('expense-living','expense','生活费'),('expense-other','expense','其他支出'),('expense-unclassified','expense','不分类');
ALTER TABLE entries ADD COLUMN category_id TEXT REFERENCES categories(id);
ALTER TABLE entries ADD COLUMN category_name TEXT;
