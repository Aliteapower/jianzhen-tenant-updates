CREATE TABLE tenant_entitlement_drafts (
  tenant_id TEXT PRIMARY KEY REFERENCES tenants(id),
  enabled INTEGER NOT NULL CHECK(enabled IN (0,1)),
  expires_on TEXT
);
