CREATE TABLE platform_branding (
  singleton INTEGER PRIMARY KEY CHECK(singleton=1),
  brand_name TEXT NOT NULL DEFAULT '',
  currency_symbol TEXT NOT NULL DEFAULT '¥',
  avatar_key TEXT,
  branding_revision INTEGER NOT NULL DEFAULT 0
);
INSERT INTO platform_branding(singleton) VALUES(1);
ALTER TABLE tenants ADD COLUMN currency_override INTEGER NOT NULL DEFAULT 0;
UPDATE tenants SET currency_override=1 WHERE currency_symbol<>'¥';
