CREATE TABLE entry_presets (
  tenant_id TEXT NOT NULL REFERENCES tenants(id),
  kind TEXT NOT NULL CHECK(kind IN ('funding','source','payee')),
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  PRIMARY KEY (tenant_id,kind,name)
);
CREATE INDEX entries_donor_lookup ON entries(ledger_id,category_id,person,status,phone);
