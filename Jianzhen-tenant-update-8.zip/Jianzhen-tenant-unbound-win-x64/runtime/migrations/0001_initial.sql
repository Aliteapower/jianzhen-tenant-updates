CREATE TABLE tenants (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, slug TEXT UNIQUE NOT NULL, active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE accounts (
  id TEXT PRIMARY KEY, tenant_id TEXT REFERENCES tenants(id), username TEXT NOT NULL, role TEXT NOT NULL,
  password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, must_change INTEGER NOT NULL DEFAULT 0,
  CHECK ((role='platform' AND tenant_id IS NULL) OR (role IN ('admin','member') AND tenant_id IS NOT NULL))
);
CREATE UNIQUE INDEX account_username ON accounts(COALESCE(tenant_id,''), username);
CREATE TABLE sessions (
  token TEXT PRIMARY KEY, account_id TEXT NOT NULL REFERENCES accounts(id), expires INTEGER NOT NULL
);
CREATE TABLE ledgers (
  id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES tenants(id), slug TEXT NOT NULL, name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '', public INTEGER NOT NULL, registration INTEGER NOT NULL,
  UNIQUE(tenant_id, slug), UNIQUE(tenant_id,id)
);
CREATE TABLE corners (
  id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL REFERENCES tenants(id), name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1, sort INTEGER NOT NULL DEFAULT 0, UNIQUE(tenant_id,name), UNIQUE(tenant_id,id)
);
CREATE TABLE grants (
  tenant_id TEXT NOT NULL, ledger_id TEXT NOT NULL, account_id TEXT NOT NULL REFERENCES accounts(id),
  income INTEGER NOT NULL, expense INTEGER NOT NULL, review INTEGER NOT NULL, view INTEGER NOT NULL,
  PRIMARY KEY(ledger_id,account_id), FOREIGN KEY(tenant_id,ledger_id) REFERENCES ledgers(tenant_id,id)
);
CREATE TABLE challenges (
  id TEXT PRIMARY KEY, ledger_id TEXT NOT NULL REFERENCES ledgers(id), code TEXT NOT NULL, expires INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE rates (
  key TEXT PRIMARY KEY, window INTEGER NOT NULL, count INTEGER NOT NULL
);
CREATE TABLE entries (
  id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, ledger_id TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('income','expense')),
  status TEXT NOT NULL CHECK(status IN ('pending','posted','rejected','void')),
  amount INTEGER NOT NULL CHECK(amount > 0), person TEXT NOT NULL, funding TEXT NOT NULL, corner_id TEXT, corner TEXT,
  address TEXT NOT NULL, phone TEXT NOT NULL, reason TEXT NOT NULL, notes TEXT NOT NULL, date TEXT NOT NULL,
  proof TEXT, request_key TEXT, challenge_id TEXT UNIQUE, actor TEXT, decision TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL, posted_at INTEGER, updated_at INTEGER NOT NULL,
  UNIQUE(ledger_id,request_key),
  FOREIGN KEY(tenant_id,ledger_id) REFERENCES ledgers(tenant_id,id),
  FOREIGN KEY(tenant_id,corner_id) REFERENCES corners(tenant_id,id)
);
CREATE INDEX entries_listing ON entries(ledger_id,status,kind,date DESC,id DESC);
CREATE TABLE audit (
  id INTEGER PRIMARY KEY, tenant_id TEXT NOT NULL, ledger_id TEXT, actor TEXT, action TEXT NOT NULL,
  target TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', at INTEGER NOT NULL
);
CREATE TRIGGER audit_entry_created AFTER INSERT ON entries BEGIN
  INSERT INTO audit(tenant_id,ledger_id,actor,action,target,at) VALUES(new.tenant_id,new.ledger_id,new.actor,new.status,new.id,new.updated_at);
END;
CREATE TRIGGER audit_entry_status AFTER UPDATE OF status ON entries WHEN new.status<>old.status BEGIN
  INSERT INTO audit(tenant_id,ledger_id,actor,action,target,detail,at) VALUES(new.tenant_id,new.ledger_id,new.actor,new.status,new.id,new.decision,new.updated_at);
END;
