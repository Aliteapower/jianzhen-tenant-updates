import { verify } from 'node:crypto'
import { readFile, writeFile, rename, mkdir } from 'node:fs/promises'
import { join } from 'node:path'

export async function readJson(path) {
  try { return JSON.parse(await readFile(path,'utf8')) }
  catch (error) { if (error.code!=='ENOENT') throw error; return null }
}

export async function channelOptions(runtime,data) {
  const config=await readJson(join(runtime,'git-channel.json'))
  if (!config) return null
  const local=await readJson(join(data,'git-channel.local.json'))
  return {...config,token:process.env.JIANZHEN_GITHUB_READ_TOKEN || local?.token || '',data}
}

export function verifyEnvelope(envelope,key,kind) {
  if (typeof envelope?.payload!=='string' || typeof envelope?.signature!=='string' || envelope.payload.length>750000)
    throw new Error('Git 清单格式错误')
  const bytes=Buffer.from(envelope.payload,'base64')
  if (!verify(null,bytes,key,Buffer.from(envelope.signature,'base64'))) throw new Error('Git 清单签名无效')
  const body=JSON.parse(bytes)
  if (body.kind!==kind || !Number.isSafeInteger(body.serial) || body.serial<1) throw new Error('Git 清单类型或版本错误')
  if (kind==='entitlements') {
    const seen=new Set()
    if (!Array.isArray(body.tenants)) throw new Error('租户授权格式错误')
    for (const row of body.tenants) {
      if (typeof row?.id!=='string' || !/^[a-z0-9-]{1,64}$/i.test(row.id) || seen.has(row.id) || typeof row.enabled!=='boolean' ||
          (row.expiresOn!==null && !validDate(row.expiresOn))) throw new Error('租户授权记录无效')
      seen.add(row.id)
    }
  } else if (kind==='tenant-renewal') {
    if (!/^[a-f0-9]{64}$/.test(body.subject || '') || !Number.isSafeInteger(body.policySerial) || body.policySerial<1 ||
        typeof body.enabled!=='boolean' || (body.expiresOn!==null && !validDate(body.expiresOn)))
      throw new Error('租户续期清单无效')
  } else if (kind==='offline-tenant') {
    const {tenant,account}=body
    if (!/^[a-z0-9-]{1,64}$/i.test(tenant?.id || '') || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(tenant.slug || '') ||
        tenant.slug.length>48 || typeof tenant.name!=='string' || !tenant.name.trim() || tenant.name.length>80 ||
        typeof tenant.enabled!=='boolean' || (tenant.expiresOn!==null && !validDate(tenant.expiresOn)))
      throw new Error('离线租户授权无效')
    if (account && (typeof account.username!=='string' || !account.username.trim() || account.username.length>60 ||
      !/^[a-f0-9]{32}:[a-f0-9]{64}$/.test(account.passwordHash || '') ||
      (account.mustChange!==undefined && typeof account.mustChange!=='boolean'))) throw new Error('平台发放的租户账号无效')
    if (body.feedUrl && new URL(body.feedUrl).protocol!=='https:') throw new Error('续期同步地址须使用 HTTPS')
  } else if ((kind!=='tenant-update' && (!Number.isSafeInteger(body.assetId) || body.assetId<1)) || !/^[a-f0-9]{64}$/.test(body.sha256 || '') ||
    !Number.isSafeInteger(body.size) || body.size<1 || body.size>400_000_000) throw new Error('更新资产信息无效')
  return body
}

function validDate(value) {
  if (typeof value!=='string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false
  const parsed = new Date(value+'T00:00:00Z')
  return Number.isFinite(+parsed) && parsed.toISOString().slice(0,10)===value
}

export function tenantAccess(policy,id,today) {
  const tenant=policy?.tenants.find(row=>row.id===id)
  if (!tenant) return policy ? 'missing' : 'unconfigured'
  if (!tenant.enabled) return 'disabled'
  return tenant.expiresOn && tenant.expiresOn<today ? 'expired' : 'active'
}

export async function github(config,path,accept='application/vnd.github+json',timeout=5000,init={}) {
  if (!/^[\w.-]+\/[\w.-]+$/.test(config.repository)) throw new Error('Git 仓库格式错误')
  const response=await fetch('https://api.github.com/repos/'+config.repository+'/'+path,{
    ...init,headers:{...init.headers,Accept:accept,...(config.token ? {Authorization:'Bearer '+config.token} : {})},
    signal:AbortSignal.timeout(timeout),
  })
  if (!response.ok) throw Object.assign(new Error('GitHub 返回 '+response.status),{status:response.status})
  return response
}

export async function storeManifest(config,kind,envelope) {
  const directory=join(config.data,'git-cache')
  const path=join(directory,kind+'.json')
  await mkdir(directory,{recursive:true})
  await writeFile(path+'.tmp',JSON.stringify(envelope))
  await rename(path+'.tmp',path)
}

export async function cachedManifest(config,kind) {
  const key=config[kind+'Key']
  const path=join(config.data,'git-cache',kind+'.json')
  const current=await readJson(path)
  const previous=current ? verifyEnvelope(current,key,kind) : null
  try {
    const remote=await github(config,'contents/channels/'+kind+'.json?ref=main')
    const payload=await remote.json()
    if (payload.encoding!=='base64' || payload.size>800000) throw new Error('Git 清单过大或格式错误')
    const envelope=JSON.parse(Buffer.from(payload.content,'base64'))
    const next=verifyEnvelope(envelope,key,kind)
    if (previous && next.serial<=previous.serial) return previous
    await storeManifest(config,kind,envelope)
    return next
  } catch (error) {
    console.warn(kind+' 同步未完成：'+error.message)
    return previous
  }
}
