import { join } from 'node:path'
import { get } from 'node:https'
import { readJson, verifyEnvelope } from './git-channel.mjs'

export function tenantManifestUrl(value) {
  const url=new URL(value)
  if (url.protocol!=='https:' || url.username || url.password || url.search || url.hash || !url.pathname.endsWith('/update.json'))
    throw new Error('租户更新清单须使用 HTTPS 的 update.json 地址')
  return url
}

export async function tenantUpdateOptions(runtime,data) {
  const config=await readJson(join(runtime,'tenant-update.json'))
  if (!config) return null
  const {serial}=await readJson(join(runtime,'desktop-version.json'))
  const {key:entitlementsKey}=await readJson(join(runtime,'offline-tenant.json'))
  return {...config,manifestUrl:tenantManifestUrl(config.manifestUrl).href,serial,entitlementsKey,data,tenant:true}
}

function fetchHttps(url,timeout) {
  return new Promise((resolve,reject)=>{
    const request=get(url,{signal:AbortSignal.timeout(timeout),headers:{'Cache-Control':'no-cache'}},response=>{
      if (response.statusCode===200) return resolve(response)
      response.destroy()
      reject(new Error('租户更新渠道返回 '+response.statusCode))
    })
    request.on('error',reject)
  })
}

export async function readTenantUpdate(config) {
  const response=await fetchHttps(config.manifestUrl,5000)
  const chunks=[]
  let length=0
  for await (const chunk of response) {
    length+=chunk.length
    if (length>16000) throw new Error('租户更新清单过大')
    chunks.push(chunk)
  }
  const envelope=JSON.parse(Buffer.concat(chunks).toString('utf8'))
  return verifyEnvelope(envelope,config.updateKey,'tenant-update')
}

export function tenantUpdateAsset(config,serial) {
  return fetchHttps(new URL('Jianzhen-tenant-update-'+serial+'.zip',config.manifestUrl),300000)
}
