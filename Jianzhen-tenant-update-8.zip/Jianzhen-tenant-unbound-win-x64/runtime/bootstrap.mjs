import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { spawn } from 'node:child_process'
import { once } from 'node:events'
import { channelOptions } from './git-channel.mjs'
import { tenantUpdateOptions } from './tenant-update.mjs'

const base=dirname(fileURLToPath(import.meta.url))
const data=resolve(process.env.JIANZHEN_DATA_DIR || join(base,'../data'))
const options=await channelOptions(base,data) || await tenantUpdateOptions(base,data)
let runtime=base
if (options) {
  try { runtime=await (await import('./update.mjs')).stagedRuntime(data,options.serial,Boolean(options.tenant)) || base }
  catch (error) { console.warn('无法读取已准备的更新：'+error.message) }
}
const child=spawn(join(runtime,'node.exe'),[join(runtime,'run.mjs'),...process.argv.slice(2)],{
  cwd:runtime,windowsHide:true,stdio:'inherit',env:{...process.env,JIANZHEN_DATA_DIR:data,JIANZHEN_BASE_RUNTIME:base},
})
const [code]=await once(child,'exit')
process.exitCode=code ?? 1
