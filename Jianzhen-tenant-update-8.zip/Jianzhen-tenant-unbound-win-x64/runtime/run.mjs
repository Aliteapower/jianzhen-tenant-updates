import { Miniflare, convertV4MiniflareOptions } from 'miniflare'
import { cp, mkdir, readFile, writeFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { spawn } from 'node:child_process'
import { once } from 'node:events'
import { createServer } from 'node:net'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { migrationFiles, migrationStatements } from './migrations.mjs'
import { cachedManifest, channelOptions, tenantAccess } from './git-channel.mjs'
import { provisionOfflineTenant, tenantEdition } from './offline-tenant.mjs'
import { desktopProgram } from './program-version.mjs'
import { tenantUpdateOptions } from './tenant-update.mjs'

const runtime = dirname(fileURLToPath(import.meta.url))
const data = resolve(process.env.JIANZHEN_DATA_DIR || join(runtime,'../data'))
const state = join(data,'state','v3')
const migrations = join(runtime,'migrations')
const config = JSON.parse(await readFile(join(runtime,'worker-config.json'),'utf8'))
const names = await migrationFiles(migrations)
const host = '127.0.0.1'
const headless = process.argv.includes('--headless')
const portFile = join(data,'listen-port')
const randomPort = headless && process.argv.includes('--random-port')
let current
await mkdir(data,{recursive:true})
const offline=await tenantEdition(runtime,data,process.env.JIANZHEN_BASE_RUNTIME || runtime)
const channel=await channelOptions(runtime,data)
const program=await desktopProgram(runtime,data,channel || (offline && await tenantUpdateOptions(runtime,data)))
const publisher=channel && await import('./entitlement-publisher.mjs')
const actions=await publisher?.publisherFor(channel)
const policyEnforced=Boolean(channel && (channel.token || existsSync(join(data,'git-cache','entitlements.json'))))
let policy=null
let policyQueue=Promise.resolve()
let offlineSync=false

async function syncOffline() {
  if (!offline || offlineSync) return
  offlineSync=true
  try { await offline.refresh() }
  catch (error) { console.warn(error.message) }
  finally { offlineSync=false }
}

function withPolicy(operation) {
  const pending=policyQueue.then(operation)
  policyQueue=pending.catch(()=>{})
  return pending
}

async function syncPolicies() {
  if (!channel) return
  await withPolicy(async()=>{
    try { policy=await cachedManifest(channel,'entitlements') || policy }
    catch (error) { console.warn('无法验证租户授权：'+error.message) }
  })
}

async function publisherBinding(request) {
  if (request.method==='GET') {
    if (!policy) return Response.json({error:'尚未读取已签名的 Git 授权'}, {status:503})
    return Response.json({tenants:policy.tenants,serial:policy.serial})
  }
  return withPolicy(async()=>{
    try {
      const {row,expected}=await request.json()
      const result=await actions.publish(row,expected)
      policy=result.policy
      try { await publisher.cachePublished(channel,result) }
      catch { console.warn('Git 已保存，写入本机授权缓存失败') }
      let renewalPublished=null
      try { renewalPublished=await actions.publishRenewal(row,policy.serial) }
      catch (error) { renewalPublished=false; console.warn('HTTPS 续期发布失败：'+error.message) }
      return Response.json({...row,commit:result.commit,serial:policy.serial,renewalPublished})
    } catch (error) {
      return Response.json({error:error.status===409 ? 'Git 授权已被修改，请重新打开窗口后再试' :
        '无法同步 Git 授权，请检查管理电脑的 Git 登录、网络和签名设置'}, {status:error.status===409 ? 409 : 503})
    }
  })
}

async function activationBinding(request) {
  if (request.method!=='POST') return new Response(null,{status:405})
  return withPolicy(async()=>{
    const {tenant,account}=await request.json()
    const entitlement=policy?.tenants.find(row=>row.id===tenant.id)
    const day=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Singapore'}).format()
    if (tenantAccess(policy,tenant.id,day)!=='active') return new Response(null,{status:403})
    try {
      return Response.json(await actions.signActivation({...tenant,enabled:entitlement.enabled,expiresOn:entitlement.expiresOn},account))
    } catch {
      return new Response(null,{status:503})
    }
  })
}

async function preferredPort() {
  if (randomPort) return 0
  const saved = Number(await readFile(portFile,'utf8').catch(error=>{
    if (error.code!=='ENOENT') throw error
    return '8791'
  }))
  if (!Number.isInteger(saved) || saved<1024 || saved>65535) return 0
  const probe=createServer()
  return new Promise((resolve,reject)=>{
    probe.once('error',error=>error.code==='EADDRINUSE' || error.code==='EACCES' ? resolve(0) : reject(error))
    probe.listen(saved,host,()=>probe.close(()=>resolve(saved)))
  })
}

function localRuntime(serveApp,port=0) {
  return new Miniflare(convertV4MiniflareOptions({
    name:config.name,host,port,modules:true,
    compatibilityDate:config.compatibility_date,resourcePersistencePath:state,telemetry:{enabled:false},
    d1Databases:Object.fromEntries(config.d1_databases.map(row=>[row.binding,row.database_id])),
    ...(serveApp ? {
      scriptPath:join(runtime,'worker.mjs'),bindings:{LOCAL_DESKTOP:'1',...(offline ? {
        OFFLINE_TENANT:JSON.stringify({id:offline.tenant.id,slug:offline.tenant.slug}),
      } : {})},
      serviceBindings:{
        DESKTOP_PROGRAM:program.binding,
        ...(actions ? {ENTITLEMENT_PUBLISHER:publisherBinding,ACTIVATION_SIGNER:activationBinding} : {}),
        ...(policyEnforced || offline ? {TENANT_POLICY:async request=>{
        const tenant=new URL(request.url).searchParams.get('tenant')
        const day=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Singapore'}).format()
        return Response.json({status:offline ? tenantAccess({tenants:[offline.tenant]},tenant,day) :
          policy ? tenantAccess(policy,tenant,day) : 'unavailable',
          expiresOn:offline && tenant===offline.tenant.id ? offline.tenant.expiresOn ?? null : undefined})
        }} : {}),
      },
      r2Buckets:Object.fromEntries(config.r2_buckets.map(row=>[row.binding,row.bucket_name])),
      assets:{directory:join(runtime,'dist'),binding:'ASSETS',
        routerConfig:{invoke_user_worker_ahead_of_assets:true,has_user_worker:true},
        assetConfig:{not_found_handling:'single-page-application'}},
    } : {script:"export default {fetch(){return new Response(null,{status:404})}}"}),
  }))
}

async function connection() {
  current=localRuntime(false)
  return current.getD1Database('DB')
}

async function closeRuntime() {
  const running=current
  current=undefined
  await running?.dispose()
}

async function migrate() {
  let db=await connection()
  await db.prepare(`CREATE TABLE IF NOT EXISTS d1_migrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT UNIQUE,applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
  )`).run()
  const {results} = await db.prepare('SELECT name FROM d1_migrations ORDER BY id').all()
  const applied = new Set(results.map(row=>row.name))
  if (results.some(row=>!names.includes(row.name))) throw new Error('账本数据由较新的程序创建，请使用对应版本启动。')
  const pending = names.filter(name=>!applied.has(name))
  if (pending.length && applied.size) {
    await closeRuntime()
    const stamp=new Date().toISOString().replace(/[:.]/g,'-')
    await cp(state,join(data,'backups',stamp,'state','v3'),{recursive:true,errorOnExist:true,force:false})
    db=await connection()
  }
  for (const name of pending) {
    const statements=await migrationStatements(migrations,name)
    await db.batch([...statements.map(statement=>db.prepare(statement)),
      db.prepare('INSERT INTO d1_migrations(name) VALUES(?)').bind(name)])
  }
  if (offline) await provisionOfflineTenant(db,offline)
  await closeRuntime()
}

function edgeExecutable() {
  const locations=[process.env['ProgramFiles(x86)'],process.env.ProgramFiles,process.env.LOCALAPPDATA]
  const edge = locations.filter(Boolean).map(folder=>join(folder,'Microsoft','Edge','Application','msedge.exe')).find(existsSync)
  if (!edge) throw new Error('找不到 Microsoft Edge，无法打开桌面窗口。')
  return edge
}

let policyTimer,updateTimer,offlineTimer
try {
  await mkdir(data,{recursive:true})
  await migrate()
  await syncPolicies()
  await syncOffline()
  current=localRuntime(true,await preferredPort())
  const address=await current.ready
  const origin=address.origin
  const check=await fetch(origin+'/api/local-setup')
  if (!check.ok) throw new Error('本地服务启动检查失败。')
  if (!randomPort) await writeFile(portFile,address.port)
  console.log('READY '+origin)
  if (offline) offlineTimer=setInterval(syncOffline,60_000)
  if (!headless) {
    if (channel) void program.prepare()
    policyTimer=setInterval(syncPolicies,300_000)
    if (channel) updateTimer=setInterval(program.prepare,300_000)
  }
  if (headless) {
    await new Promise(resolve=>{
      process.once('SIGINT',resolve)
      process.once('SIGTERM',resolve)
      process.stdin.once('data',resolve)
      process.stdin.resume()
    })
    process.stdin.pause()
  } else {
    const entrance=offline ? '/v/'+offline.tenant.slug+'/admin' : '/admin'
    const edge = spawn(edgeExecutable(),['--app='+origin+entrance,'--user-data-dir='+join(data,'edge-profile'),
      '--no-first-run','--disable-background-mode','--disable-features=EdgeFirstRunExperience'],{stdio:'ignore',windowsHide:true})
    const [code]=await once(edge,'exit')
    if (code) throw new Error('Microsoft Edge 桌面窗口异常退出。')
  }
} catch (error) {
  console.error(error)
  process.exitCode=1
} finally {
  clearInterval(offlineTimer)
  clearInterval(policyTimer)
  clearInterval(updateTimer)
  await closeRuntime()
}
