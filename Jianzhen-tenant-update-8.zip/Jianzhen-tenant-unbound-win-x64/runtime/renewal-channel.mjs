import { createHash, sign } from 'node:crypto'
import { github, verifyEnvelope } from './git-channel.mjs'

export const renewalSubject=id=>createHash('sha256').update('jianzhen:tenant-renewal:v1:'+id).digest('hex')

export function renewalUrl(base,id) {
  const url=new URL(base)
  if (url.protocol!=='https:' || url.username || url.password || url.search || url.hash || !url.pathname.endsWith('/'))
    throw new Error('续期渠道须使用 HTTPS 目录地址')
  return new URL(renewalSubject(id)+'.json',url).href
}

export async function publishRenewal(config,key,row,policySerial,request=github) {
  const subject=renewalSubject(row.id)
  const path='contents/renewals/'+subject+'.json'
  for(let attempt=0;attempt<3;attempt++) {
    const file=await request(config,path+'?ref=main').then(response=>response.json()).catch(error=>{
      if (error.status!==404) throw error
      return null
    })
    let previous=null
    if (file) {
      if (file.encoding!=='base64' || file.size>16000 || typeof file.sha!=='string') throw new Error('续期清单格式无效')
      previous=verifyEnvelope(JSON.parse(Buffer.from(file.content,'base64')),config.entitlementsKey,'tenant-renewal')
      if (previous.subject!==subject) throw new Error('续期清单标识不符')
      if (previous.policySerial>=policySerial) return
    }
    const record={kind:'tenant-renewal',subject,policySerial,serial:Math.max(Date.now(),(previous?.serial ?? 0)+1),
      enabled:row.enabled,expiresOn:row.expiresOn}
    const bytes=Buffer.from(JSON.stringify(record))
    const envelope={payload:bytes.toString('base64'),signature:sign(null,bytes,key).toString('base64')}
    verifyEnvelope(envelope,config.entitlementsKey,'tenant-renewal')
    try {
      await request(config,path,undefined,12000,{method:'PUT',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({branch:'main',...(file ? {sha:file.sha} : {}),message:'Publish signed tenant renewal',
          content:Buffer.from(JSON.stringify(envelope)+'\n').toString('base64')})})
      return
    } catch (error) {
      if (![409,422].includes(error.status) || attempt===2) throw error
    }
  }
}
