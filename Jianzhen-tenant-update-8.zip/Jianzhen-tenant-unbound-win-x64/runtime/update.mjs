import { createHash } from 'node:crypto'
import { createWriteStream } from 'node:fs'
import { mkdir, mkdtemp, rename, writeFile, access, rm } from 'node:fs/promises'
import { execFile } from 'node:child_process'
import { join } from 'node:path'
import { Readable, Transform } from 'node:stream'
import { pipeline } from 'node:stream/promises'
import { promisify } from 'node:util'
import { cachedManifest, github, readJson } from './git-channel.mjs'
import { tenantUpdateAsset } from './tenant-update.mjs'

const exec = promisify(execFile)
const versions = data=>join(data,'program-versions')

export async function stagedRuntime(data,baseSerial,tenant=false) {
  const pointer=await readJson(join(versions(data),'ready.json'))
  if (!Number.isSafeInteger(pointer?.serial) || pointer.serial<=baseSerial || Boolean(pointer.tenant)!==tenant) return null
  const runtime=join(versions(data),String(pointer.serial),'runtime')
  await access(join(runtime,'node.exe'))
  return runtime
}

async function download(config,manifest,zip) {
  const body=config.tenant ? await tenantUpdateAsset(config,manifest.serial) :
    Readable.fromWeb((await github(config,'releases/assets/'+manifest.assetId,'application/octet-stream',300000)).body)
  const hash=createHash('sha256')
  let length=0
  await pipeline(body,new Transform({
    transform(chunk,encoding,callback) {
      length+=chunk.length
      if (length>manifest.size) return callback(new Error('更新包超过清单大小'))
      hash.update(chunk)
      callback(null,chunk)
    },
  }),createWriteStream(zip,{flags:'wx'}))
  if (length!==manifest.size || hash.digest('hex')!==manifest.sha256) throw new Error('更新包哈希或长度不符')
}

async function extract(config,manifest,staging,zip) {
  const packageName=config.tenant ? 'Jianzhen-tenant-unbound-win-x64' : 'Jianzhen-portable-win-x64'
  const {stdout}=await exec('tar.exe',['-tf',zip],{windowsHide:true,maxBuffer:8_000_000})
  for (const line of stdout.trim().split(/\r?\n/)) {
    const parts=line.split('/')
    if (parts[0]!==packageName || parts[1]==='data' || parts.some(part=>part==='..' || part==='.' || /[:\\]/.test(part)))
      throw new Error('更新包目录结构无效')
    if (config.tenant && /^runtime\/(tenant-license\.json|git-channel\.json|entitlement-publisher\.mjs)$/i.test(parts.slice(1).join('/')))
      throw new Error('租户更新包包含非通用配置')
  }
  await exec('tar.exe',['-xf',zip,'-C',staging],{windowsHide:true,timeout:90000})
  const extracted=join(staging,packageName)
  const runtime=join(extracted,'runtime')
  if (config.tenant) {
    const metadata=await readJson(join(runtime,'desktop-version.json'))
    const newer=await readJson(join(runtime,'tenant-update.json'))
    const offline=await readJson(join(runtime,'offline-tenant.json'))
    if (metadata?.serial!==manifest.serial || newer?.manifestUrl!==config.manifestUrl ||
        newer?.updateKey!==config.updateKey || offline?.key!==config.entitlementsKey)
      throw new Error('租户更新包版本或信任配置不匹配')
  } else {
    const newer=await readJson(join(runtime,'git-channel.json'))
    if (newer?.serial!==manifest.serial || newer.repository!==config.repository ||
        newer.updateKey!==config.updateKey || newer.entitlementsKey!==config.entitlementsKey)
      throw new Error('更新包版本或信任配置和签名清单不一致')
  }
  await access(join(runtime,'run.mjs'))
  await access(join(runtime,'node.exe'))
  return extracted
}

export async function stageUpdate(config,baseSerial,manifest) {
  if (manifest===undefined && !config.tenant) manifest=await cachedManifest(config,'update')
  if (!manifest || manifest.serial<=baseSerial) return
  const folder=versions(config.data)
  const ready=await stagedRuntime(config.data,baseSerial,Boolean(config.tenant)).catch(()=>null)
  const current=ready && await readJson(join(folder,'ready.json'))
  if (current?.serial>=manifest.serial) return
  await mkdir(folder,{recursive:true})
  const staging=await mkdtemp(join(folder,'download-'))
  const zip=join(staging,'update.zip')
  try {
    await download(config,manifest,zip)
    const extracted=await extract(config,manifest,staging,zip)
    const destination=join(folder,String(manifest.serial))
    const pointer=join(folder,'ready.json')
    const temporary=join(staging,'ready.json')
    await writeFile(temporary,JSON.stringify({serial:manifest.serial,tenant:Boolean(config.tenant)}))
    await rename(extracted,destination)
    try { await rename(temporary,pointer) }
    catch (error) { await rename(destination,extracted); throw error }
  } finally { await rm(staging,{recursive:true,force:true}) }
}
