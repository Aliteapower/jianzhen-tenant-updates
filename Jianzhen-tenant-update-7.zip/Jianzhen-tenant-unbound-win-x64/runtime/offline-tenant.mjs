import { readFile, rename, stat, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { readJson, verifyEnvelope } from './git-channel.mjs'

export function offlineLicense(key,initial,renewal) {
  const base=verifyEnvelope(initial,key,'offline-tenant')
  if (!renewal) return base
  const newer=verifyEnvelope(renewal,key,'offline-tenant')
  if (base.tenant.id!==newer.tenant.id || base.tenant.slug!==newer.tenant.slug)
    throw new Error('授权文件不属于此租户')
  return newer.serial>base.serial ? newer : base
}

export async function installTenantActivation(runtime,data,source) {
  const file=await stat(source)
  if (!file.isFile() || file.size>16000) throw new Error('激活文件格式不正确')
  const bytes=await readFile(source)
  if (bytes.length>16000) throw new Error('激活文件过大')
  const envelope=JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/,''))
  await acceptTenantActivation(runtime,data,envelope)
}

export async function acceptTenantActivation(runtime,data,envelope) {
  const config=await readJson(join(runtime,'offline-tenant.json'))
  if (!config) throw new Error('此程序不是租户版')
  const activation=offlineLicense(config.key,envelope,null)
  if (!activation.account) throw new Error('请选择平台签发的首次激活文件')
  await writeFile(join(data,'tenant-activation.json'),JSON.stringify(envelope)+'\n',{flag:'wx'})
}

export async function tenantEdition(runtime,data,baseRuntime=runtime) {
  const config=await readJson(join(runtime,'offline-tenant.json'))
  if (!config) return null
  const initial=await readJson(join(baseRuntime,'tenant-license.json')) || await readJson(join(data,'tenant-activation.json'))
  if (!initial) throw new Error('缺少租户激活文件：请将平台发给你的 tenant-activation.json 放入 data 目录')
  const renewal=await readJson(join(data,'tenant-license.json'))
  const retained=await readJson(join(data,'tenant-license.accepted.json'))
  const old=offlineLicense(config.key,initial,retained)
  const first=offlineLicense(config.key,initial,null)
  if (!first.account) throw new Error('首装包缺少平台发放的租户账号')
  const edition={tenant:old.tenant,account:first.account}
  let serial=old.serial
  let feedUrl=old.feedUrl || first.feedUrl
  async function accept(envelope) {
    const next=offlineLicense(config.key,initial,envelope)
    if (next.serial<=serial) return
    const temp=join(data,'tenant-license.accepted.tmp')
    await writeFile(temp,JSON.stringify(envelope))
    await rename(temp,join(data,'tenant-license.accepted.json'))
    edition.tenant=next.tenant
    feedUrl=next.feedUrl || feedUrl
    serial=next.serial
  }
  if (renewal) await accept(renewal).catch(error=>console.warn(error.message))
  return Object.assign(edition,{async refresh(fetcher=fetch) {
    if (!feedUrl) return
    const response=await fetcher(feedUrl,{cache:'no-store',signal:AbortSignal.timeout(5000),redirect:'error'})
    if (!response.ok) throw new Error('暂时无法读取租户续期授权')
    const body=await response.text()
    if (body.length>16000) throw new Error('租户续期授权过大')
    await accept(JSON.parse(body))
  }})
}

export async function provisionOfflineTenant(db,{tenant,account}) {
  const {results}=await db.prepare('SELECT id,slug FROM tenants').all()
  if (results.some(row=>row.id!==tenant.id || row.slug!==tenant.slug) ||
      await db.prepare("SELECT 1 FROM accounts WHERE role='platform'").first())
    throw new Error('数据目录属于其他租户，请使用此租户的独立目录')
  if (results.length) return
  await db.batch([
    db.prepare('INSERT INTO tenants(id,slug,name,active) VALUES(?,?,?,1)').bind(tenant.id,tenant.slug,tenant.name),
    db.prepare("INSERT INTO accounts(id,tenant_id,username,role,password_hash,must_change) VALUES(?,?,?,'admin',?,?)")
      .bind(crypto.randomUUID(),tenant.id,account.username,account.passwordHash,Number(account.mustChange!==false)),
  ])
}
