ALTER TABLE ledgers ADD COLUMN opening_income INTEGER NOT NULL DEFAULT 0 CHECK (opening_income >= 0);
ALTER TABLE ledgers ADD COLUMN opening_expense INTEGER NOT NULL DEFAULT 0 CHECK (opening_expense >= 0);
UPDATE ledgers SET opening_income=max(opening_balance,0), opening_expense=max(-opening_balance,0)
WHERE opening_balance<>0;
