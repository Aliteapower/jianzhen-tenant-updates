ALTER TABLE ledgers ADD COLUMN opening_channels TEXT NOT NULL DEFAULT '[]';

UPDATE ledgers
SET opening_channels=json_array(json_object('funding','','income',opening_income,'expense',opening_expense))
WHERE opening_income<>0 OR opening_expense<>0;
